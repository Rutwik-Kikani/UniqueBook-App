﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniqueBooks.Dtos
{
    public class MembershipTypeDto
    {
        public byte Id { get; set; }
        public string MembershipName { get; set; }
    }
}