﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniqueBooks.Dtos
{
    public class GenerDto
    {
        public byte Id { get; set; }
        public string GenreName { get; set; }
    }
}