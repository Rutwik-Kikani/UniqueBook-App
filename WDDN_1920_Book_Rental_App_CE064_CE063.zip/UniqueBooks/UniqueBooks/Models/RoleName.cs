﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniqueBooks.Models
{
    public class RoleName
    {
        public const string CanManageCustomer = "CanManageCustomer";
    }
}