Project Description:

This system is Book Rental App,
Customer can rent available books.
Application can record all the rentals.
Admin can add,update,delete Books data ans Customers data.
Admin:
login: vivek211@mybooks.com 
password: Vivek@korat211

First page:

	view -> Home -> index.cshtml	

Contributor's IDs:

	ID2:17CEUOG128 NAME:VIVEK KORAT
	ID1:17CEUOS068 NAME:RUTWIK KIKANI
 